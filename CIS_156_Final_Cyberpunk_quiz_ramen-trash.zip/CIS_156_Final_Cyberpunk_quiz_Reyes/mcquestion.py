import random

class MCquestion():
    def __init__(self, question, correct, wrong1, wrong2, wrong3):
        self.__question = question
        self.__correct = correct
        self.__wrong1 = wrong1
        self.__wrong2 = wrong2
        self.__wrong3 = wrong3
        self.__order = [correct, wrong1, wrong2, wrong3]  # later randomly ordered
        self.__correct_answer = "A"

    def set_question(self, value):
        self.__question = value

    def set_correct(self, value):
        self.__correct = value

    def set_wrong1(self, value):
        self.__wrong1 = value

    def set_wrong2(self, value):
        self.__wrong2 = value

    def set_wrong3(self, value):
        self.__wrong3 = value

    def get_correct_answer(self):
        return self.__correct_answer

    def randomizeAnswers(self):
        # this method randomizes the order of the answers and stores them
        # in attributes of the instance along with which letter
        # (A, B, C, or D) is correct.
        used = [False, False, False, False]  # used to ensure distribution
        letters = ["A", "B", "C", "D"]  # used for marking the correct answer
        c = random.randint(0, 3)  # c becomes the correct answer
        used[c] = True  # mark that slot as used
        self.__correct_answer = letters[c]

        # now let's randomize the three wrong answers into the remaining slots
        w1 = w2 = w3 = c
        while used[w1]:
            w1 = random.randint(0, 3)
        used[w1] = True
        self.__order[w1] = self.__wrong1

        # position the second wrong answer
        while used[w2]:
            w2 = random.randint(0, 3)
        used[w2] = True
        self.__order[w2] = self.__wrong2

        # position the third wrong answer
        while used[w3]:
            w3 = random.randint(0, 3)
        used[w3] = True
        self.__order[w3] = self.__wrong3

    def __str__(self):
        # prints the question and the randomly-ordered answers
        self.randomizeAnswers()
        return (
            self.__question
            + "\n   A - "
            + self.__order[0]
            + "\n   B - "
            + self.__order[1]
            + "\n   C - "
            + self.__order[2]
            + "\n   D - "
            + self.__order[3]
        )
