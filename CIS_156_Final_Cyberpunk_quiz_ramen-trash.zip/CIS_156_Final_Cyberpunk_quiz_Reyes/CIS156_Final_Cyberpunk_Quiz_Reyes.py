import mcquestion
import random
def main():
    global questions, correct, incorrect
    questions = []  # Empty list
    readData()
    askQuestions()


def readData():
    global datafile, questions
    try:
        datafile = open("cyberpunk_quiz.txt", 'r')
        line = datafile.readline().rstrip("\n")  # Ignore first line - header
        line = datafile.readline().rstrip("\n")
        # DATA FORMAT: Question\tCorrect\tWrong1\tWrong2\tWrong3
        while len(line) > 5:
            items = line.split("\t")  # Datafile fields delimited by tabs
            questions.append(items)
            line = datafile.readline().rstrip("\n")
        datafile.close()
        print("Question data has been imported.")
    except Exception as ex:
        print("Something went wrong. Data not read.")
        print(ex)


def askQuestions():
    global questions, correct, incorrect
    correct = incorrect = 0
    for i, q in enumerate(questions):
        print(f"\n{i + 1}.) {q[0]}")
        choices = q[1:]
        random.shuffle(choices)  # Shuffle the choices to randomize their order
        for j, choice in enumerate(choices):
            print(f"{chr(65 + j)}. {choice}")
        user_choice = input("Enter your answer choice (A, B, C, or D): ").upper()
        correct_choice = chr(65 + choices.index(q[1]))
        if user_choice == correct_choice:
            correct += 1
            print("Good job Samurai - That was the right answer!")
        else:
            incorrect += 1
            print(f"Sorry Choom, but that wasn't the right answer. The correct answer is ({correct_choice}).")
        input("Press Enter to continue.")

    # Show score at the end
    print(f"\nAlright Choom, You got {correct} of {len(questions)} questions correct. Nice, now let's go to the AfterLife.")


main()